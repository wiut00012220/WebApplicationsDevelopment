﻿using DataBaseAcces.Models;
using DataBaseAcces.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace OnlineStoreAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class cartController : Controller
    {

       
            private readonly ICartRepository _cartRepository;

            public cartController(ICartRepository cartRepository)
            {
                _cartRepository = cartRepository;
            }

            [HttpPost]
            public IActionResult AddToCart(cart Cart)
            {
                try
                {
                    _cartRepository.AddToCart(Cart);
                    return Ok();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            [HttpGet("{id}")]
            public IActionResult GetCartItem(int id)
            {
                try
                {
                    var cartItem = _cartRepository.GetCartItem(id);
                    if (cartItem != null)
                    {
                        return Ok(cartItem);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            [HttpGet]
            public IActionResult GetCartItems()
            {
                try
                {
                    var cartItems = _cartRepository.GetCartItems();
                    return Ok(cartItems);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            [HttpDelete("{id}")]
            public IActionResult RemoveFromCart(int id)
            {
                try
                {
                    _cartRepository.RemoveFromCart(id);
                    return Ok();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

            [HttpPut]
            public IActionResult UpdateCartItem(cart cart)
            {
                try
                {
                    _cartRepository.UpdateCartItem(cart);
                    return Ok();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }


            // GET: cartController
            public ActionResult Index()
            {
                return View();
            }

            // GET: cartController/Details/5
            public ActionResult Details(int id)
            {
                return View();
            }

            // GET: cartController/Create
            public ActionResult Create()
            {
                return View();
            }

            // POST: cartController/Create
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Create(IFormCollection collection)
            {
                try
                {
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }

            // GET: cartController/Edit/5
            public ActionResult Edit(int id)
            {
                return View();
            }

            // POST: cartController/Edit/5
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Edit(int id, IFormCollection collection)
            {
                try
                {
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }

            // GET: cartController/Delete/5
            public ActionResult Delete(int id)
            {
                return View();
            }

            // POST: cartController/Delete/5
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Delete(int id, IFormCollection collection)
            {
                try
                {
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }
        }
    }
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineStoreAPI.Models;
using OnlineStoreAPI.Repositories;

namespace OnlineStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class productController : ControllerBase
    {
        private readonly IProductRepository __productRepository;

        public productController(IProductRepository productRepository)
        {
            __productRepository = productRepository;
        }

        // GET: api/tOrders
        [HttpGet]
        public IActionResult Get() 
        {
            return new OkObjectResult(__productRepository.RetrieveAll());
        }

        // GET: api/tOrders/5
        [HttpGet("{id}", Name ="GetProductByID")]
        public IActionResult GetProductById(int ID) 
        {
            return new OkObjectResult(__productRepository.RetrieveByID(ID));
        }

        // PUT: api/tOrders/5
        [HttpPut("{id}")]
        public IActionResult UpdateProduct([FromBody] product oProduct) 
        {
            if (oProduct != null) 
            {
                using (var scope = new TransactionScope()) 
                {
                    __productRepository.UpdateProduct(oProduct);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        // POST: 

        [HttpPost]
        public IActionResult CreateNewProduct(product oProduct) 
        {
            using (var scope = new TransactionScope())
            {
                __productRepository.CreateNewProduct(oProduct);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { ID = oProduct.Id }, oProduct);
            }

        }

        // DELETE: api/tOrders/5
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int ID) 
        {

            __productRepository.DeleteProductByID(ID);
            return new OkResult();
        }
    }
}

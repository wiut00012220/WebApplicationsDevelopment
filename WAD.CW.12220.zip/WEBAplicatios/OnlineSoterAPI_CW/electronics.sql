﻿INSERT INTO [dbo].[Products] (ProductName, ProductDescription, ProductPrice, ProductCategory, ProductQuantity)
VALUES 
('Apple iPhone 12 Pro Max', '6.7-inch Super Retina XDR display, Ceramic Shield with 4x better drop performance, A14 Bionic chip, 5G capable', 1099, 'Electronics', 50),
('Samsung Galaxy S21 Ultra', '6.8-inch Dynamic AMOLED 2X display, Corning Gorilla Glass Victus, Exynos 2100 chipset, 5G capable', 1199, 'Electronics', 30),
('Sony WH-1000XM4', 'Noise-cancelling wireless headphones with exceptional sound quality, long battery life, and touch controls', 349, 'Electronics', 20),
('Apple MacBook Pro 16-inch', '16-inch Retina display, 8-core 9th-generation Intel Core i9 processor, AMD Radeon Pro 5500M graphics', 2399, 'Electronics', 10),
('Nike Air Zoom Pegasus 38', 'Running shoes with responsive Zoom Air cushioning, comfortable fit, and durable design', 120, 'Sports', 100),
('Adidas Ultraboost 21', 'High-performance running shoes with responsive Boost cushioning, breathable Primeknit upper, and durable outsole', 180, 'Sports', 80),
('Under Armour Men’s Tech 2.0 Short Sleeve T-Shirt', 'Moisture-wicking and quick-drying athletic shirt with anti-odor technology and soft feel', 25, 'Sports', 150),
('Lululemon Align Pant 28”', 'Buttery-soft, lightweight leggings with high-rise waist, comfortable fit, and four-way stretch', 98, 'Sports', 60),
('T-fal E93808 Professional Nonstick Fry Pan', 'Durable and scratch-resistant frying pan with Thermo-Spot heat indicator and comfortable silicone handle', 35, 'Kitchen', 50),
('Instant Pot Duo 7-in-1 Electric Pressure Cooker', 'Multi-functional pressure cooker with 14 built-in programs, easy-to-use control panel, and stainless steel cooking pot', 79, 'Kitchen', 30);

INSERT INTO [dbo].[Carts] (ProductName, ProductDescription, ProductPrice, ProductQuantity)
VALUES 
('Apple iPhone 12 Pro Max', '6.7-inch Super Retina XDR display, Ceramic Shield with 4x better drop performance, A14 Bionic chip, 5G capable', 1099, 50),
('Samsung Galaxy S21 Ultra', '6.8-inch Dynamic AMOLED 2X display, Corning Gorilla Glass Victus, Exynos 2100 chipset, 5G capable', 1199,  30),
('Sony WH-1000XM4', 'Noise-cancelling wireless headphones with exceptional sound quality, long battery life, and touch controls', 349, 20),
('Apple MacBook Pro 16-inch', '16-inch Retina display, 8-core 9th-generation Intel Core i9 processor, AMD Radeon Pro 5500M graphics', 2399, 10);
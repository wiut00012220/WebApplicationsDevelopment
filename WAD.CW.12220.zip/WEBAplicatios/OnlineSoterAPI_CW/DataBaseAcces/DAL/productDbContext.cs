﻿using DataBaseAcces.Models;
using Microsoft.EntityFrameworkCore;
using OnlineStoreAPI.Models;

namespace OnlineStoreAPI.DAL
{
    public class productDbContext:DbContext
    {
        public productDbContext(DbContextOptions<productDbContext> options):base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<product> Products { get; set; }
        public DbSet<cart> Carts { get; set; }
    }
}

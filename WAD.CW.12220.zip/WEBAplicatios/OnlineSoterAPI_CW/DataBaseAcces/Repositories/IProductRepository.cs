﻿using System.Collections.Generic;
using OnlineStoreAPI.Models;

namespace OnlineStoreAPI.Repositories
{
    public interface IProductRepository
    {
       
        void CreateNewProduct(product oProduct);

      
        IEnumerable<product> RetrieveAll();
        
        
        product RetrieveByID(int ProductId);

      
        void DeleteProductByID(int ProductId);
        
        
        void UpdateProduct(product oProduct);

    }
}

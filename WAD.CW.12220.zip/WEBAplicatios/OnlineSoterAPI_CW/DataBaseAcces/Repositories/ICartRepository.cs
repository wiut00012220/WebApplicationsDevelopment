﻿using DataBaseAcces.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataBaseAcces.Repositories
{
    public interface ICartRepository
    {

        void AddToCart(cart Cart);
        void RemoveFromCart(int cartId);
        IEnumerable<cart> GetCartItems();
        cart GetCartItem(int cartId);
        void UpdateCartItem(cart Cart);
    }

}

﻿using System;
using System.Collections.Generic;
using OnlineStoreAPI.Models;
using OnlineStoreAPI.DAL;
using System.Linq;

namespace OnlineStoreAPI.Repositories
{
    public class ProductRepository : IProductRepository
    {
        // initializing dbcontext public to private
        private readonly productDbContext __dbContext;
        public ProductRepository(productDbContext dbContext)
        {
            __dbContext = dbContext;
        }

        // Save function implemented later
        public void Save() 
        {
            __dbContext.SaveChanges();
        }

        public void CreateNewProduct(product oProduct)
        {
            __dbContext.Add(oProduct);
            Save();

        }

        public void DeleteProductByID(int ProductID)
        {
            var foundProduct = __dbContext.Products.Find(ProductID);
            __dbContext.Products.Remove(foundProduct);
            Save();
        }

        public IEnumerable<product> RetrieveAll()
        {
            return __dbContext.Products.ToList();
        }

        public product RetrieveByID(int ProductID)
        {
            
            return __dbContext.Products.Find(ProductID);
        }

        public void UpdateProduct(product oProduct)
        {
            __dbContext.Entry(oProduct).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Save();
        }
    }
}

﻿using DataBaseAcces.Models;
using Microsoft.EntityFrameworkCore;
using OnlineStoreAPI.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataBaseAcces.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly productDbContext __dbContext;

        public CartRepository(productDbContext dbContext)
        {
            __dbContext = dbContext;
        }

        // Save function implemented later
        public void Save()
        {
            __dbContext.SaveChanges();
        }
        public void AddToCart(cart Cart)
        {
            __dbContext.Carts.Add(Cart);
            Save();
        }

        public cart GetCartItem(int cartId)
        {
            return __dbContext.Carts.FirstOrDefault(c => c.Id == cartId);
        }

        public IEnumerable<cart> GetCartItems()
        {
            return __dbContext.Carts.ToList();
        }

        public void RemoveFromCart(int cartId)
        {
            var cartItem = __dbContext.Carts.Find(cartId);
            if (cartItem != null)
            {
                __dbContext.Carts.Remove(cartItem);
                Save();
            }
        }

        public void UpdateCartItem(cart cart)
        {
             var existingCartItem = __dbContext.Carts.Find(cart.Id);
    if (existingCartItem != null)
    {
        existingCartItem.ProductQuantity = cart.ProductQuantity;
        existingCartItem.ProductPrice = cart.ProductPrice;
        Save();
    }
        }
    }
}

﻿use [OnlineStoreDB]
Go
insert into [dbo].Products
([ProductName], [ProductDescription], [ProductPrice], [ProductCategory])
values ('Onion', 'Raw Onion for Household', 10,2)
Go